
.onLoad <- function(libname, pkgname) {
  stop("This will fail when loading the package")
}
