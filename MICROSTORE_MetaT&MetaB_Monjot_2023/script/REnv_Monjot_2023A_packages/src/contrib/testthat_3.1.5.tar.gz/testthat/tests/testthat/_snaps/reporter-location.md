# reporter as expected

    Start test: Success
      'reporters/tests.R:6' [success]
    End test: Success
    
    Start test: Failure:1
      'reporters/tests.R:12' [failure]
    End test: Failure:1
    
    Start test: Failure:2a
      'reporters/tests.R:17' [failure]
    End test: Failure:2a
    
    Start test: Error:1
      'reporters/tests.R:23' [error]
    End test: Error:1
    
    Start test: errors get tracebacks
      'reporters/tests.R:31' [error]
    End test: errors get tracebacks
    
    Start test: explicit skips are reported
      'reporters/tests.R:37' [skip]
    End test: explicit skips are reported
    
    Start test: empty tests are implicitly skipped
      'reporters/tests.R:40' [skip]
    End test: empty tests are implicitly skipped
    
    Start test: warnings get backtraces
      'reporters/tests.R:49' [warning]
      'reporters/tests.R:45' [skip]
    End test: warnings get backtraces
    

