library(testthat)
library(emmeans)

test_check("emmeans")
