library(testthat)
library(shades)

test_check("shades")
