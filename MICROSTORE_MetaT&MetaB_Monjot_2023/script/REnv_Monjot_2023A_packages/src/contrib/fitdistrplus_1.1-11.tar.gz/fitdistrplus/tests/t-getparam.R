library(fitdistrplus)


computegetparam <- fitdistrplus:::computegetparam


computegetparam(names(formals(dgamma)))
computegetparam(names(formals(pgamma)))
computegetparam(names(formals(qgamma)))


computegetparam(names(formals(dnbinom)))
