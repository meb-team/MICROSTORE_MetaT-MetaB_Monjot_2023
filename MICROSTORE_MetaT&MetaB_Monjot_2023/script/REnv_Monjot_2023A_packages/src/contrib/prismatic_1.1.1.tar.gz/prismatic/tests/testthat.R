library(testthat)
library(prismatic)

test_check("prismatic")
