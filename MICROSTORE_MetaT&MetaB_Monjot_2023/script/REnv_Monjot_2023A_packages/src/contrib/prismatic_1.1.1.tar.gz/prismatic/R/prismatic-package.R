#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom farver convert_colour
#' @importFrom farver decode_colour
#' @importFrom farver encode_colour
#' @importFrom graphics plot
#' @importFrom graphics rect
#' @importFrom graphics text
#' @importFrom grDevices col2rgb
#' @importFrom grDevices rgb
## usethis namespace: end
NULL
