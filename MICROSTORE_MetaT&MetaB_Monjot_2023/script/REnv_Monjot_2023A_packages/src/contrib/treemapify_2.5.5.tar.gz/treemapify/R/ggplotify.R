#' ggplotify
#' @noRd
ggplotify <- function(...) {
  .Deprecated("geom_treemap")
}
