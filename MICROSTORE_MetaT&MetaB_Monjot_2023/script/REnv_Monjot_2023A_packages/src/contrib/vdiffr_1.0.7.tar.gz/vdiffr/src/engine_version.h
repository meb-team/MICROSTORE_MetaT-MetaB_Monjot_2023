#pragma once

#include <string>

std::string get_engine_version();
