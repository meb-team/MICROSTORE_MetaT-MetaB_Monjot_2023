library("testthat")

test_check("SciViews")
