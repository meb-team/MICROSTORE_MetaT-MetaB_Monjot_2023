# useful warnings

    [<text>:3] @includeRmd Can't find Rmd 'path'

---

    Code
      . <- roc_proc_text(rd_roclet(), text)
    Message
      Quitting from lines 2-3 (<temp-path.Rmd>) 
      Quitting from lines 2-3 (<temp-path.Rmd>) 
    Condition
      Warning:
      [<text>:3] @includeRmd failed to evaluate '<temp-path.Rmd>'
      Caused by error:
      ! Error

