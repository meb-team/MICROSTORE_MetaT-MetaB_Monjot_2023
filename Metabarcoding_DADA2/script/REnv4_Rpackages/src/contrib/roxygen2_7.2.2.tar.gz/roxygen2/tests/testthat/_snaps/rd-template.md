# templates gives useful error if not found

    Code
      roc_proc_text(rd_roclet(), block)
    Condition
      Error:
      ! Can't find template "doesn't-exist"

