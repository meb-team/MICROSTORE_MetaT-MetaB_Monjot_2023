# warning for both @md and @noMd

    [<text>:5] @md conflicts with @noMd; turning markdown parsing off

