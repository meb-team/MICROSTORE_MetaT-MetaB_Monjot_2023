#' 中文注释
#'
#' @note 我爱中文。
printChineseMsg <- function() {
}
