# extract_r6_data without source refs

    Code
      extract_r6_data(C)
    Condition
      Error:
      ! R6 class <foo> lacks source references.
      i If you are using the `installed` load method in `DESCRIPTION`, then try re-installing the package with option '--with-keep.source', e.g. `install.packages(..., INSTALL_OPTS = "--with-keep.source")`.

