# Manually edited the Collate field in the DESCRIPTION file so this *should*
# run after b.r

a <- 1
