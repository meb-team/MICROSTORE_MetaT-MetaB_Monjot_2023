library(testthat)
library(paletteer)

test_check("paletteer")
