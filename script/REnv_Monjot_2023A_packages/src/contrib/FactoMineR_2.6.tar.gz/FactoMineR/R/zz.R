.onLoad <-
function(libname,pkgname){
library.dynam("FactoMineR",pkgname,libname)
}