# strip_vanilla rejects faulty arguments

    `clip` must be one of "on", "off", or "inherit", not "nonsense".

---

    `size` must be one of "constant" or "variable", not "nonsense".

# strip_themed rejects faulty theme elements

    The `background_x` argument should be a list of <element_rect> objects.

---

    The `text_y` argument should be a list of <element_text> objects.

