# guide_axis_minor errors upon misuse

    Guide `axis` cannot be used for colour.

---

    `guide_axis_minor()` needs appropriate scales.
    i Use one of z.

