# guide_axis_nested errors upon misuse

    Guide `axis` cannot be used for fill.

---

    Axis guide lacks appropriate scales.
    i Use one of z

