# guide_axis_logticks errors upon misuse

    Guide `axis` cannot be used for colour.

---

    `guide_axis_logticks()` needs appropriate scales.
    i Use one of z.

